import sqlite3
from pathlib import Path

DB_PATH = Path.home() / ".aivas" / "aivas.db"


def get_db(path: Path = DB_PATH) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def create_schema(conn: sqlite3.Connection) -> None:
    conn.executescript("""
        PRAGMA foreign_keys = ON;

        CREATE TABLE IF NOT EXISTS cves (
            cve_id          TEXT PRIMARY KEY,
            description     TEXT NOT NULL,
            published       TEXT,
            last_modified   TEXT,
            vuln_status     TEXT,
            cvss_score      REAL,
            cvss_severity   TEXT,
            cvss_vector     TEXT,
            attack_vector   TEXT,
            cwe_id          TEXT,
            kev             INTEGER DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS cpe_matches (
            id                  INTEGER PRIMARY KEY AUTOINCREMENT,
            cve_id              TEXT NOT NULL REFERENCES cves(cve_id),
            cpe_criteria        TEXT NOT NULL,
            version_start_incl  TEXT,
            version_start_excl  TEXT,
            version_end_incl    TEXT,
            version_end_excl    TEXT,
            vulnerable          INTEGER DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS scans (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            target          TEXT NOT NULL,
            started_at      TEXT NOT NULL,
            finished_at     TEXT,
            host_count      INTEGER DEFAULT 0,
            finding_count   INTEGER DEFAULT 0,
            risk_score      REAL,
            grade           TEXT,
            report_path     TEXT,
            scan_level      INTEGER DEFAULT 1,
            provider        TEXT DEFAULT 'groq'
        );

        CREATE TABLE IF NOT EXISTS findings (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_id         INTEGER NOT NULL REFERENCES scans(id),
            host            TEXT NOT NULL,
            port            INTEGER,
            protocol        TEXT,
            service         TEXT,
            product         TEXT,
            version         TEXT,
            cve_id          TEXT,
            cvss_score      REAL,
            cvss_severity   TEXT,
            confidence      TEXT,
            en_risk         TEXT,
            sw_risk         TEXT,
            en_fix          TEXT,
            sw_fix          TEXT,
            resolved        INTEGER DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS sync_meta (
            key     TEXT PRIMARY KEY,
            value   TEXT
        );

        CREATE INDEX IF NOT EXISTS idx_cpe_criteria
            ON cpe_matches(cpe_criteria);
        CREATE INDEX IF NOT EXISTS idx_cve_severity
            ON cves(cvss_severity);
        CREATE INDEX IF NOT EXISTS idx_findings_scan
            ON findings(scan_id);
        CREATE INDEX IF NOT EXISTS idx_findings_host
            ON findings(host);
        CREATE INDEX IF NOT EXISTS idx_findings_cve
            ON findings(cve_id);

        CREATE TABLE IF NOT EXISTS chat_sessions (
            id          TEXT PRIMARY KEY,
            title       TEXT,
            created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS chat_messages (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id   TEXT NOT NULL REFERENCES chat_sessions(id) ON DELETE CASCADE,
            role         TEXT NOT NULL CHECK(role IN ('user','assistant','tool')),
            content      TEXT,
            tool_calls   TEXT,
            tool_call_id TEXT,
            created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE INDEX IF NOT EXISTS idx_chat_messages_session_time
            ON chat_messages(session_id, created_at);

        CREATE TABLE IF NOT EXISTS cve_advice (
            cve_id      TEXT PRIMARY KEY,
            advice_en   TEXT NOT NULL,
            advice_sw   TEXT NOT NULL,
            model       TEXT NOT NULL,
            created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS remote_targets (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            label       TEXT NOT NULL,
            host        TEXT NOT NULL,
            method      TEXT NOT NULL DEFAULT 'ssh',
            username    TEXT NOT NULL,
            password    TEXT,
            port        INTEGER,
            key_path    TEXT,
            created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS scheduled_scans (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            label            TEXT NOT NULL,
            target           TEXT NOT NULL,
            remote_target_id INTEGER REFERENCES remote_targets(id) ON DELETE SET NULL,
            interval         TEXT NOT NULL DEFAULT 'daily',
            enabled          INTEGER DEFAULT 1,
            last_run         TEXT,
            next_run         TEXT NOT NULL,
            created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS users (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            username    TEXT NOT NULL UNIQUE COLLATE NOCASE,
            password_hash TEXT NOT NULL,
            role        TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('admin','user')),
            created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    """)
    conn.commit()
    # Migration: add kev column if DB predates this sprint
    try:
        conn.execute("ALTER TABLE cves ADD COLUMN kev INTEGER DEFAULT 0")
        conn.commit()
    except Exception:
        pass  # column already exists
    # Migration: add remote_targets table if DB predates this sprint
    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS remote_targets (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                label       TEXT NOT NULL,
                host        TEXT NOT NULL,
                method      TEXT NOT NULL DEFAULT 'ssh',
                username    TEXT NOT NULL,
                password    TEXT,
                port        INTEGER,
                key_path    TEXT,
                created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()
    except Exception:
        pass
    # Migration: add password column to remote_targets if it predates this sprint
    try:
        conn.execute("ALTER TABLE remote_targets ADD COLUMN password TEXT")
        conn.commit()
    except Exception:
        pass  # column already exists
    # Migration: add scheduled_scans table if DB predates this sprint
    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS scheduled_scans (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                label            TEXT NOT NULL,
                target           TEXT NOT NULL,
                remote_target_id INTEGER REFERENCES remote_targets(id) ON DELETE SET NULL,
                interval         TEXT NOT NULL DEFAULT 'daily',
                enabled          INTEGER DEFAULT 1,
                last_run         TEXT,
                next_run         TEXT NOT NULL,
                created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()
    except Exception:
        pass
    # Migration: add label column to scans if DB predates this sprint
    try:
        conn.execute("ALTER TABLE scans ADD COLUMN label TEXT")
        conn.commit()
    except Exception:
        pass  # column already exists
    # Migration: add users table
    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                username    TEXT NOT NULL UNIQUE COLLATE NOCASE,
                password_hash TEXT NOT NULL,
                role        TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('admin','user')),
                created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()
    except Exception:
        pass
    # Migration: add user_id to scans
    try:
        conn.execute("ALTER TABLE scans ADD COLUMN user_id INTEGER REFERENCES users(id) ON DELETE SET NULL")
        conn.commit()
    except Exception:
        pass
    # Migration: add user_id to chat_sessions
    try:
        conn.execute("ALTER TABLE chat_sessions ADD COLUMN user_id INTEGER REFERENCES users(id) ON DELETE SET NULL")
        conn.commit()
    except Exception:
        pass
    # Migration: add misconfigs JSON column to scans
    try:
        conn.execute("ALTER TABLE scans ADD COLUMN misconfigs TEXT DEFAULT '[]'")
        conn.commit()
    except Exception:
        pass
    # Migration: link scans to chat sessions
    try:
        conn.execute("ALTER TABLE scans ADD COLUMN session_id TEXT REFERENCES chat_sessions(id) ON DELETE SET NULL")
        conn.commit()
    except Exception:
        pass
    # Migration: store scan progress log
    try:
        conn.execute("ALTER TABLE scans ADD COLUMN scan_log TEXT DEFAULT '[]'")
        conn.commit()
    except Exception:
        pass
